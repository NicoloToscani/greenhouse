﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Timers;
using Sharp7;

namespace Progetto_Supervisione_ITIS
{
    public class S7PlcService : IS7PlcService
    {
        private readonly S7Client _client;
        private readonly System.Timers.Timer _timer;
        private readonly System.Timers.Timer _modbusTimer;
        private DateTime _lastScanTime;

        private volatile object _locker = new object();



        public S7PlcService()
        {
            _client = new S7Client();
            _timer = new System.Timers.Timer();
            _timer.Interval = 100;
           _timer.Elapsed += OnTimerElapsed;

            Console.WriteLine("Chiamata servizio");
        }



        public ConnectionStates ConnectionState { get; private set; }

        public bool TBX_segnalazione { get; private set; } // Interno 1


        public TimeSpan ScanTime { get; private set; }

        public event EventHandler ValuesRefreshed;

        public void Connect(string ipAddress, int rack, int slot)
        {
            try
            {
                Console.WriteLine("Chiamata la connessione");
                ConnectionState = ConnectionStates.Connecting;
                int result = _client.ConnectTo(ipAddress, rack, slot);
                if (result == 0)
                {
                    ConnectionState = ConnectionStates.Online;
                    _timer.Start(); // Avviotimer aggiornamento variabili
                    
                    Console.WriteLine("Connesso");


                }
               
                OnValuesRefreshed();
            }
            catch
            {
                ConnectionState = ConnectionStates.Offline;
                OnValuesRefreshed();
                throw;
            }
        }

        public void Disconnect()
        {
            if (_client.Connected)
            {
                _timer.Stop();
                _client.Disconnect();
                ConnectionState = ConnectionStates.Offline;
                OnValuesRefreshed();

            }
        }


        // Start BT_1
        public async Task Start_BT_1()
        {
            await Task.Run(() =>
            {
                Console.WriteLine("BT_1");
                int writeResult = WriteBit("DB1.DBX0.0", true);
                if (writeResult != 0)
                {
                    //Debug.WriteLine(DateTime.Now.ToString("HH:mm:ss") + "\t Write error: " + _client.ErrorText(writeResult));
                }
                Thread.Sleep(30);
                writeResult = WriteBit("DB1.DBX0.0", false);
                if (writeResult != 0)
                {
                    //Debug.WriteLine(DateTime.Now.ToString("HH:mm:ss") + "\t Write error: " + _client.ErrorText(writeResult));
                }
            });
        }

        // Stop BT_1
        public async Task Stop_BT_1()
        {
            await Task.Run(() =>
            {
                int writeResult = WriteBit("DB1.DBX0.1", true);
                if (writeResult != 0)
                {
                    //Debug.WriteLine(DateTime.Now.ToString("HH:mm:ss") + "\t Write error: " + _client.ErrorText(writeResult));
                }
                Thread.Sleep(30);
                writeResult = WriteBit("DB1.DBX0.1", false);
                if (writeResult != 0)
                {
                    //Debug.WriteLine(DateTime.Now.ToString("HH:mm:ss") + "\t Write error: " + _client.ErrorText(writeResult));
                }
            });
        }





        private void RefreshValues()
        {
            lock (_locker)
            {
                var buffer = new byte[1];
                int result = _client.DBRead(1, 0, buffer.Length, buffer);
                if (result == 0)
                {

                    TBX_segnalazione = S7.GetBitAt(buffer, 0, 2); // Segnalazione zona 1

                }

            }
        }




        private int WriteBit(string address, bool value)
        {
            var strings = address.Split('.');
            int db = Convert.ToInt32(strings[0].Replace("DB", ""));
            int pos = Convert.ToInt32(strings[1].Replace("DBX", ""));
            int bit = Convert.ToInt32(strings[2]);
            return WriteBit(db, pos, bit, value);
        }

        private int WriteBit(int db, int pos, int bit, bool value)
        {
            lock (_locker)
            {
                var buffer = new byte[4];
                S7.SetBitAt(ref buffer, pos, bit, value);
                return _client.WriteArea(S7Consts.S7AreaDB, db, pos + bit, buffer.Length, S7Consts.S7WLBit, buffer);
            }
        }


        // Timer chiamata aggiornamento 
        private void OnTimerElapsed(object sender, ElapsedEventArgs e)
        {
            try
            {
                _timer.Stop();
                ScanTime = DateTime.Now - _lastScanTime;
                RefreshValues();
                OnValuesRefreshed();
            }
            finally
            {
                _timer.Start();
            }
            _lastScanTime = DateTime.Now;
        }

        private void OnValuesRefreshed()
        {

            if (ConnectionState == ConnectionStates.Online) Console.WriteLine("Connesso");
            else if (ConnectionState == ConnectionStates.Offline) Console.WriteLine("Disconnesso");
            else if (ConnectionState == ConnectionStates.Connecting) Console.WriteLine("In connessione");

            

            ValuesRefreshed?.Invoke(this, new EventArgs());
        }

        public void Connect()
        {
            throw new NotImplementedException();
        }





    }
}
