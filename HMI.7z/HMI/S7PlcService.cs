﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Timers;
using Sharp7;

namespace Progetto_Supervisione_ITIS
{
    public class S7PlcService : IS7PlcService
    {
        // 
        private readonly S7Client _client;

        private readonly System.Timers.Timer _timer;
        private readonly System.Timers.Timer _modbusTimer;
        private DateTime _lastScanTime;

        private volatile object _locker = new object();


        // Costruttore
        public S7PlcService()
        {
            _client = new S7Client();

            _timer = new System.Timers.Timer();
            _timer.Interval = 100;
            _timer.Elapsed += OnTimerElapsed;

            Console.WriteLine("Chiamata servizio");
        }



        public ConnectionStates ConnectionState { get; private set; }

        public bool TBX_segnalazione { get; private set; } // Interno 1

        public string TBX_sensore { get; private set; }

        public bool Stato_Luce { get; private set;}

        public bool Stato_Emergenza { get; private set; }

        public TimeSpan ScanTime { get; private set; }

        public event EventHandler ValuesRefreshed;

        public List<int> values = new List<int>();
        public List<int> temperature = new List<int>();
        public List<int> humidity = new List<int>();
        public List<int> rain = new List<int>();


        public void Connect(string ipAddress, int rack, int slot)
        {
            try
            {
                Console.WriteLine("Chiamata la connessione");
                ConnectionState = ConnectionStates.Connecting;
                int result = _client.ConnectTo(ipAddress, rack, slot);
                if (result == 0)
                {
                    ConnectionState = ConnectionStates.Online;
                    _timer.Start(); // Avviotimer aggiornamento variabili
                    
                    Console.WriteLine("Connesso");

                }
               
                OnValuesRefreshed();
            }
            catch
            {
                ConnectionState = ConnectionStates.Offline;
                OnValuesRefreshed();
                throw;
            }
        }

        public void Disconnect()
        {
            if (_client.Connected)
            {
                _timer.Stop();
                _client.Disconnect();
                ConnectionState = ConnectionStates.Offline;
                OnValuesRefreshed();

            }
        }

        // Scrittura
        // Start BT_1
        public async Task Start_BT_1()
        {
            await Task.Run(() =>
            {
                Console.WriteLine("BT_1");
                int writeResult = WriteBit("DB1.DBX0.7", true);
                if (writeResult != 0)
                {
                    //Debug.WriteLine(DateTime.Now.ToString("HH:mm:ss") + "\t Write error: " + _client.ErrorText(writeResult));
                }
                
            });
        }

        // Accesione luce manuale
        public async Task Start_light()
        {
            await Task.Run(() =>
            {
                if(ConnectionState == ConnectionStates.Online)
                {
                    //Console.WriteLine("BT_1");
                    int writeResult = WriteBit("DB1.DBX0.5", true);
                    if (writeResult != 0)
                    {
                        //Debug.WriteLine(DateTime.Now.ToString("HH:mm:ss") + "\t Write error: " + _client.ErrorText(writeResult));
                    }

                    Thread.Sleep(1000);

                    writeResult = WriteBit("DB1.DBX0.5", false);
                    if (writeResult != 0)
                    {
                        //Debug.WriteLine(DateTime.Now.ToString("HH:mm:ss") + "\t Write error: " + _client.ErrorText(writeResult));
                    }
                }

                
                    

            });
        }

        // Spegnimento luce se valore sopra 50
        public async Task Stop_light()
        {
            await Task.Run(() =>
            {

                if (ConnectionState == ConnectionStates.Online)
                {
                    //Console.WriteLine("BT_1");
                    int writeResult = WriteBit("DB1.DBX0.6", true);
                    if (writeResult != 0)
                    {
                        //Debug.WriteLine(DateTime.Now.ToString("HH:mm:ss") + "\t Write error: " + _client.ErrorText(writeResult));
                    }

                    Thread.Sleep(1000);

                    writeResult = WriteBit("DB1.DBX0.6", false);
                    if (writeResult != 0)
                    {
                        //Debug.WriteLine(DateTime.Now.ToString("HH:mm:ss") + "\t Write error: " + _client.ErrorText(writeResult));
                    }
                }
            });
        }


        //Servo sx manual open
        public async Task Servo_Open_Sx()
        {
            await Task.Run(() =>
            {

                if (ConnectionState == ConnectionStates.Online)
                {
                    //Console.WriteLine("BT_1");
                    int writeResult = WriteBit("DB1.DBX0.12", true);
                    if (writeResult != 0)
                    {
                        //Debug.WriteLine(DateTime.Now.ToString("HH:mm:ss") + "\t Write error: " + _client.ErrorText(writeResult));
                    }

                    Thread.Sleep(1000);

                    writeResult = WriteBit("DB1.DBX0.12", false);
                    if (writeResult != 0)
                    {
                        //Debug.WriteLine(DateTime.Now.ToString("HH:mm:ss") + "\t Write error: " + _client.ErrorText(writeResult));
                    }
                }
            });
        }


        //servo sx manual close
        public async Task Servo_Close_Sx()
        {
            await Task.Run(() =>
            {

                if (ConnectionState == ConnectionStates.Online)
                {
                    //Console.WriteLine("BT_1");
                    int writeResult = WriteBit("DB1.DBX0.13", true);
                    if (writeResult != 0)
                    {
                        //Debug.WriteLine(DateTime.Now.ToString("HH:mm:ss") + "\t Write error: " + _client.ErrorText(writeResult));
                    }

                    Thread.Sleep(1000);

                    writeResult = WriteBit("DB1.DBX0.13", false);
                    if (writeResult != 0)
                    {
                        //Debug.WriteLine(DateTime.Now.ToString("HH:mm:ss") + "\t Write error: " + _client.ErrorText(writeResult));
                    }
                }
            });
        }

        // Stop BT_1
        public async Task Stop_BT_1()
        {
            await Task.Run(() =>
            {
                int writeResult = WriteBit("DB1.DBX0.7", false);
                if (writeResult != 0)
                {
                    //Debug.WriteLine(DateTime.Now.ToString("HH:mm:ss") + "\t Write error: " + _client.ErrorText(writeResult));
                }
                
            });
        }

        public async Task BT_reset_plc()
        {
            await Task.Run(() =>
            {
                int writeResult = WriteBit("DB1.DBX0.12", true);
                if (writeResult != 0)
                {
                    //Debug.WriteLine(DateTime.Now.ToString("HH:mm:ss") + "\t Write error: " + _client.ErrorText(writeResult));
                }
                Thread.Sleep(1000);
               
                writeResult = WriteBit("DB1.DBX0.12", false);
                if (writeResult != 0)
                {
                    //Debug.WriteLine(DateTime.Now.ToString("HH:mm:ss") + "\t Write error: " + _client.ErrorText(writeResult));
                }
               
            });
        }


        public async Task mod_L(string luogo, int valore)
        {
            await Task.Run(() =>
            {
                if (ConnectionState == ConnectionStates.Online)
                {
                    Console.WriteLine("Luogo: " + luogo + " valore: " + valore);
                    
                    int writeResult = WriteInt(luogo, valore);
                    if (writeResult != 0)
                    {
                        //Debug.WriteLine(DateTime.Now.ToString("HH:mm:ss") + "\t Write error: " + _client.ErrorText(writeResult));
                        
                    }
                }
            });
        }








        // lettura PLC
        // Chiamata ad ogni scadere del timer
        private void RefreshValues()
        {
            lock (_locker)
            {
                //lettura di un bit / bool
                var buffer = new byte[2];
                int result = _client.DBRead(1, 0, buffer.Length, buffer);
                if (result == 0)
                {

                    TBX_segnalazione = S7.GetBitAt(buffer, 0, 7); // Segnalazione zona 1

                    Stato_Luce = S7.GetBitAt(buffer, 1, 0); // Segnalazione zona 1

                }

                //lettura di un bit allarmi
                var buffer_alarms = new byte[2];
                int result_alarms = _client.DBRead(4, 0, buffer.Length, buffer);
                if (result_alarms == 0)
                {

                    Stato_Emergenza = S7.GetBitAt(buffer, 0, 0); // Segnalazione zona 1

                }

                //lettura intero
                var buffer1 = new byte[2];
                // Start inizio variabile intera
                int res1 = _client.DBRead(1, 6, buffer1.Length, buffer1);
                if (result == 0)
                { 
                    int test = S7.GetIntAt(buffer1,0);
                }

                //lettura contatore
                var buffer_cont = new byte[2];
                // Start inizio variabile intera
                int res_cont = _client.DBRead(1, 4, buffer_cont.Length, buffer_cont);   // 1 (numero db), 4 (posizione inizio byte), buffer_cont.lenght (lunghezza del buffer che vogliamo leggere), buffer_cont (dove vogliamo che vadano salvati i dati)
                if (result == 0)
                {
                    int test = S7.GetIntAt(buffer_cont, 0); //buffer_cont = misura contenuta nell buffer coinvertita ad intero (uso getintat, se fosse float uso getfloatat), 0 = posizione del bit da ui voglio leggere
                    TBX_sensore = test.ToString();
                }


                //lettura luce
                var bufferLight = new byte[2];
                // Start inizio variabile intera
                int resLight = _client.DBRead(2, 0, bufferLight.Length, bufferLight);
                if (resLight == 0)
                {
                    int light = S7.GetIntAt(bufferLight, 0);                    

                    if (light >= 0 && light <= 100)
                    {
                        this.values.Add(light);
                    }
                }

                //lettura temperatura
                var bufferTemperature = new byte[2];
                // Start inizio variabile intera
                int resTemperature = _client.DBRead(2, 4, bufferTemperature.Length, bufferTemperature);
                if (resTemperature == 0)
                {
                    int temperature_app = S7.GetIntAt(bufferTemperature, 0);
                    
                    if(temperature_app >= 0 && temperature_app <= 100)
                    {
                        this.temperature.Add(temperature_app);
                    }
                    
                }

                //lettura umidità
                var bufferHumidity = new byte[2];
                // Start inizio variabile intera
                int resHumidity = _client.DBRead(2, 2, bufferHumidity.Length, bufferHumidity);
                if (resHumidity == 0)
                {
                    int humidity_app = S7.GetIntAt(bufferHumidity, 0);                    

                    if (humidity_app >= 0 && humidity_app <= 100)
                    {
                        this.humidity.Add(humidity_app);
                    }
                }

                //lettura rain
                var bufferRain = new byte[2];
                // Start inizio variabile intera
                int resRain = _client.DBRead(2, 6, bufferRain.Length, bufferRain);
                if (resRain == 0)
                {
                    int Rain_app = S7.GetIntAt(bufferRain, 0);                   

                    if (Rain_app >= 0 && Rain_app <= 100)
                    {
                        this.rain.Add(Rain_app);
                    }
                }
            }
        }




        // Passacarte 1
        private int WriteBit(string address, bool value)
        {
            var strings = address.Split('.');
            int db = Convert.ToInt32(strings[0].Replace("DB", ""));
            int pos = Convert.ToInt32(strings[1].Replace("DBX", ""));
            int bit = Convert.ToInt32(strings[2]);
            return WriteBit(db, pos, bit, value);
        }

        // Passacarte bool
        private int WriteBit(int db, int pos, int bit, bool value)
        {
            lock (_locker)
            {
                var buffer = new byte[4];
                S7.SetBitAt(ref buffer, pos, bit, value);
                return _client.WriteArea(S7Consts.S7AreaDB, db, pos + bit, buffer.Length, S7Consts.S7WLBit, buffer);
            }
        }

        private int WriteInt(string address, int value)
        {
            var strings = address.Split('.');
            int db = Convert.ToInt32(strings[0].Replace("DB", ""));
            int pos = Convert.ToInt32(strings[1].Replace("DBD", ""));
            return WriteInt(db, pos, value);
        }


        // Passacarte int
        private int WriteInt(int db, int pos, int value)
        {
            lock (_locker)
            {
                short v = (short)value;
                var buffer = new byte[2];
                S7.SetIntAt(buffer, 0, v);
                // S7.SetBitAt(ref buffer, pos, bit, value);
                return _client.DBWrite(db, pos, buffer.Length, buffer);
            }
        }

        //controlli per inizio lettura
        // Timer chiamata aggiornamento 
        private void OnTimerElapsed(object sender, ElapsedEventArgs e)
        {
            try
            {
                _timer.Stop();
                ScanTime = DateTime.Now - _lastScanTime;
                RefreshValues();    //richiamo il metodo lettura
                OnValuesRefreshed();    //richiamo metodo per la condizione di connesione 
            }
            finally
            {
                _timer.Start();
            }
            _lastScanTime = DateTime.Now;
        }

        // metodo per la condizione di connesione
        private void OnValuesRefreshed()
        {

            if (ConnectionState == ConnectionStates.Online) Console.WriteLine("Connesso");
            else if (ConnectionState == ConnectionStates.Offline) Console.WriteLine("Disconnesso");
            else if (ConnectionState == ConnectionStates.Connecting) Console.WriteLine("In connessione");

            

            ValuesRefreshed?.Invoke(this, new EventArgs());
        }

        public void Connect()
        {
            throw new NotImplementedException();
        }





    }
}
