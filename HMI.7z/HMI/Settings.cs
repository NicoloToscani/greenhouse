﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;
using LiveCharts;
using LiveCharts.Defaults;
using LiveCharts.Wpf;

namespace Progetto_Supervisione_ITIS
{
    public partial class Settings : Form
    {
        private readonly System.Timers.Timer _timer;
        public string IpAddress
        {
            get { return _ipAddress; }
            set { _ipAddress = value; }
        }
        private string _ipAddress;

        public string PlcConnectionState
        {
            get { return _plcConnectionState; }
            set { _plcConnectionState = value; }
        }
        private string _plcConnectionState;

        private bool emergenza;

        public int Rack
        {
            get { return _rack; }
            set { _rack = value; }
        }
        private int _rack;

        public int Slot
        {
            get { return _slot; }
            set { _slot = value; }
        }
        private int _slot;

        public Settings()
        {
            InitializeComponent();
        }

        public Settings(S7PlcService s7PlcService)
        {
            this.s7PlcService = s7PlcService;
            InitializeComponent();

            _timer = new System.Timers.Timer();
            _timer.Interval = 100;
            _timer.Elapsed += OnTimerElapsed;
            _timer.Start();


        }

        S7PlcService s7PlcService;

        public ConnectionStates ConnectionState
        {
            get { return _connectionState; }
            set { _connectionState = value; }
        }
        private ConnectionStates _connectionState;

        public void Connect()
        {
            s7PlcService.Connect(IpAddress, Rack, Slot);

        }

        private void BT_Connessione_Click(object sender, EventArgs e)
        {
            IpAddress = TBX_IP_Plc.Text;
            Rack = Int32.Parse(TBX_Rack_1.Text);
            Slot = Int32.Parse(TBX_Slot_1.Text);
            Connect();
        }

        private void Disconnect()
        {
            s7PlcService.Disconnect();

        }
        private void BT_Disconnetti_Click(object sender, EventArgs e)
        {
            Disconnect();
        }

        private async Task BT_Start_Click()
        {
            await s7PlcService.Start_BT_1();
        }

        private async Task BT_Stop_Click()
        {
            await s7PlcService.Stop_BT_1();
        }

        // Chiamata timer
        private void OnTimerElapsed(object sender, ElapsedEventArgs e)
        {
            OnPlcServiceValuesRefreshed();
        }

        public void OnPlcServiceValuesRefreshed()
        {
            // Stato connessione
            ConnectionState = s7PlcService.ConnectionState;

            try
            {
                this.Invoke((MethodInvoker)delegate ()
                {

                    if (ConnectionState == ConnectionStates.Online)
                    {
                        TBX_Connection_State.Text = "Connesso";
                    }
                    else if (ConnectionState == ConnectionStates.Offline)
                    {
                        TBX_Connection_State.Text = "Disconnesso";
                    }
                    else if (ConnectionState == ConnectionStates.Connecting)
                    {
                        TBX_Connection_State.Text = "In connessione";
                    }

                    // Gestione aggiornamento UI bit lampade

                    ConnectionState = s7PlcService.ConnectionState;

                    this.emergenza = s7PlcService.Stato_Emergenza;

                    if(this.emergenza == true)
                    {
                        BL_emergenza.On = true;
                    }
                    else BL_emergenza.On = false;

                });
            }
            catch (Exception e)
            {
                Console.WriteLine("Arresto in corso");
            }

        }


       

            private async void SAVE_LIGHT_Click(object sender, EventArgs e)
        {
            int valMax_L = int.Parse(TXB_MAX_L.Text);
            string lMax = "DB5.DBD34";
            int valore_MAX = valMax_L;
            s7PlcService.mod_L(lMax, valore_MAX);

            int valMin_L = int.Parse(TXB_MIN_L.Text);
            string lMin = "DB5.DBD32";
            int valore_MIN = valMin_L;
            s7PlcService.mod_L(lMin, valore_MIN);

            int val_T_Max_L = int.Parse(TXB_MAX_TMP_L.Text);
            string l_T_Max = "DB5.DBD50";
            int valore_T_MAX = val_T_Max_L;
            s7PlcService.mod_L(l_T_Max, valore_T_MAX);

            int val_T_Min_L = int.Parse(TXB_MIN_TMP_L.Text);
            string l_T_Min = "DB5.DBD48";
            int valore_T_MIN = val_T_Min_L;
            s7PlcService.mod_L(l_T_Min, valore_T_MIN);
        }
         private void SAVE_RAIN_Click(object sender, EventArgs e)
        {
            int valMax_L = int.Parse(TXB_MAX_R.Text);
            string lMax = "DB5.DBD46";
            int valore_MAX = valMax_L;
            s7PlcService.mod_L(lMax, valore_MAX);

            int valMin_L = int.Parse(TXB_MIN_R.Text);
            string lMin = "DB5.DBD44";
            int valore_MIN = valMin_L;
            s7PlcService.mod_L(lMin, valore_MIN);

            int val_T_Max_L = int.Parse(TXB_MAX_TMP_R.Text);
            string l_T_Max = "DB5.DBD62";
            int valore_T_MAX = val_T_Max_L;
            s7PlcService.mod_L(l_T_Max, valore_T_MAX);

            int val_T_Min_L = int.Parse(TXB_MIN_TMP_R.Text);
            string l_T_Min = "DB5.DBD60";
            int valore_T_MIN = val_T_Min_L;
            s7PlcService.mod_L(l_T_Min, valore_T_MIN);
        }

        private void SAVE_TEMPERATURE_Click(object sender, EventArgs e)
        {
            int valMax_L = int.Parse(TXB_MAX_T.Text);
            string lMax = "DB5.DBD42";
            int valore_MAX = valMax_L;
            s7PlcService.mod_L(lMax, valore_MAX);

            int valMin_L = int.Parse(TXB_MIN_T.Text);
            string lMin = "DB5.DBD40";
            int valore_MIN = valMin_L;
            s7PlcService.mod_L(lMin, valore_MIN);

            int val_T_Max_L = int.Parse(TXB_MAX_TMP_T.Text);
            string l_T_Max = "DB5.DBD58";
            int valore_T_MAX = val_T_Max_L;
            s7PlcService.mod_L(l_T_Max, valore_T_MAX);

            int val_T_Min_L = int.Parse(TXB_MIN_TMP_T.Text);
            string l_T_Min = "DB5.DBD56";
            int valore_T_MIN = val_T_Min_L;
            s7PlcService.mod_L(l_T_Min, valore_T_MIN);
        }

        private void SAVE_HUMIDITY_Click(object sender, EventArgs e)
        {
            int valMax_L = int.Parse(TXB_MAX_H.Text);
            string lMax = "DB5.DBD38";
            int valore_MAX = valMax_L;
            s7PlcService.mod_L(lMax, valore_MAX);

            int valMin_L = int.Parse(TXB_MIN_H.Text);
            string lMin = "DB5.DBD36";
            int valore_MIN = valMin_L;
            s7PlcService.mod_L(lMin, valore_MIN);

            int val_T_Max_L = int.Parse(TXB_MAX_TMP_H.Text);
            string l_T_Max = "DB5.DBD54";
            int valore_T_MAX = val_T_Max_L;
            s7PlcService.mod_L(l_T_Max, valore_T_MAX);

            int val_T_Min_L = int.Parse(TXB_MIN_TMP_H.Text);
            string l_T_Min = "DB5.DBD52";
            int valore_T_MIN = val_T_Min_L;
            s7PlcService.mod_L(l_T_Min, valore_T_MIN);
        }

        private void SAVE_SX_SERVO_Click(object sender, EventArgs e)
        {
            int valMax_L = int.Parse(TXB_MAX_SX_S.Text);
            string lMax = "DB1.DBD12";
            int valore_MAX = valMax_L;
            s7PlcService.mod_L(lMax, valore_MAX);

            int valMin_L = int.Parse(TXB_MIN_SX_S.Text);
            string lMin = "DB1.DBD16";
            int valore_MIN = valMin_L;
            s7PlcService.mod_L(lMin, valore_MIN);
        }

        private void SAVE_DX_SERVO_Click(object sender, EventArgs e)
        {
            int valMax_L = int.Parse(TXB_MAX_DX_S.Text);
            string lMax = "DB5.DBD10";
            int valore_MAX = valMax_L;
            s7PlcService.mod_L(lMax, valore_MAX);

            int valMin_L = int.Parse(TXB_MIN_DX_S.Text);
            string lMin = "DB5.DBD14";
            int valore_MIN = valMin_L;
            s7PlcService.mod_L(lMin, valore_MIN);
        }
    
        private void TBX_Connection_State_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel21_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label24_Click(object sender, EventArgs e)
        {

        }
    }
}
