﻿namespace Progetto_Supervisione_ITIS
{
    partial class Main_Window
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.label5 = new System.Windows.Forms.Label();
            this.cartesianChart1 = new LiveCharts.WinForms.CartesianChart();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.LVCHART_temperature = new LiveCharts.WinForms.CartesianChart();
            this.panel3 = new System.Windows.Forms.Panel();
            this.LVCHART_humidity = new System.Windows.Forms.Label();
            this.LVCHART_Humid = new LiveCharts.WinForms.CartesianChart();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.SD_light = new LiveCharts.WinForms.SolidGauge();
            this.label9 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.SD_temperature = new LiveCharts.WinForms.SolidGauge();
            this.label10 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.SD_humidity = new LiveCharts.WinForms.SolidGauge();
            this.label11 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.TXB_temperature = new System.Windows.Forms.TextBox();
            this.TXB_humidity = new System.Windows.Forms.TextBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.BL_rain = new Bulb.LedBulb();
            this.BL_humidity = new Bulb.LedBulb();
            this.BL_temperature = new Bulb.LedBulb();
            this.TXB_rain = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.label21 = new System.Windows.Forms.Label();
            this.SD_rain = new LiveCharts.WinForms.SolidGauge();
            this.label22 = new System.Windows.Forms.Label();
            this.LB_light = new Bulb.LedBulb();
            this.label13 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.bt_setting = new System.Windows.Forms.Button();
            this.panel11 = new System.Windows.Forms.Panel();
            this.LVCHART_Rain = new LiveCharts.WinForms.CartesianChart();
            this.label19 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.BT_M_Servo_SX_OFF = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.BT_M_Servo_SX_ON = new System.Windows.Forms.Button();
            this.BT_M_Servo_DX_OFF = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.BT_M_Servo_DX_ON = new System.Windows.Forms.Button();
            this.panel13 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.BT_M_light_OFF = new System.Windows.Forms.Button();
            this.BT_M_light_ON = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel13.SuspendLayout();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(136, 14);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 18);
            this.label5.TabIndex = 20;
            this.label5.Text = "Light";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // cartesianChart1
            // 
            this.cartesianChart1.BackColor = System.Drawing.Color.White;
            this.cartesianChart1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.cartesianChart1.Location = new System.Drawing.Point(10, 44);
            this.cartesianChart1.Name = "cartesianChart1";
            this.cartesianChart1.Size = new System.Drawing.Size(309, 290);
            this.cartesianChart1.TabIndex = 19;
            this.cartesianChart1.Text = "cartesianChart1";
            this.cartesianChart1.ChildChanged += new System.EventHandler<System.Windows.Forms.Integration.ChildChangedEventArgs>(this.cartesianChart1_ChildChanged);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Silver;
            this.panel2.Controls.Add(this.cartesianChart1);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Location = new System.Drawing.Point(15, 344);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(333, 348);
            this.panel2.TabIndex = 26;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(124, 14);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(103, 18);
            this.label6.TabIndex = 22;
            this.label6.Text = "Temperature";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // LVCHART_temperature
            // 
            this.LVCHART_temperature.BackColor = System.Drawing.Color.White;
            this.LVCHART_temperature.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.LVCHART_temperature.Location = new System.Drawing.Point(11, 44);
            this.LVCHART_temperature.Name = "LVCHART_temperature";
            this.LVCHART_temperature.Size = new System.Drawing.Size(309, 290);
            this.LVCHART_temperature.TabIndex = 21;
            this.LVCHART_temperature.Text = "cartesianChart2";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Silver;
            this.panel3.Controls.Add(this.LVCHART_temperature);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Location = new System.Drawing.Point(352, 344);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(333, 348);
            this.panel3.TabIndex = 27;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // LVCHART_humidity
            // 
            this.LVCHART_humidity.AutoSize = true;
            this.LVCHART_humidity.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LVCHART_humidity.Location = new System.Drawing.Point(137, 14);
            this.LVCHART_humidity.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LVCHART_humidity.Name = "LVCHART_humidity";
            this.LVCHART_humidity.Size = new System.Drawing.Size(73, 18);
            this.LVCHART_humidity.TabIndex = 24;
            this.LVCHART_humidity.Text = "Humidity";
            // 
            // LVCHART_Humid
            // 
            this.LVCHART_Humid.BackColor = System.Drawing.Color.White;
            this.LVCHART_Humid.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.LVCHART_Humid.Location = new System.Drawing.Point(10, 44);
            this.LVCHART_Humid.Name = "LVCHART_Humid";
            this.LVCHART_Humid.Size = new System.Drawing.Size(309, 290);
            this.LVCHART_Humid.TabIndex = 23;
            this.LVCHART_Humid.Text = "cartesianChart3";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Silver;
            this.panel4.Controls.Add(this.LVCHART_Humid);
            this.panel4.Controls.Add(this.LVCHART_humidity);
            this.panel4.Location = new System.Drawing.Point(689, 344);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(333, 348);
            this.panel4.TabIndex = 28;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(11, 317);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(137, 24);
            this.label7.TabIndex = 29;
            this.label7.Text = "Recived data:";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DarkGray;
            this.panel5.Controls.Add(this.label14);
            this.panel5.Controls.Add(this.SD_light);
            this.panel5.Controls.Add(this.label9);
            this.panel5.Location = new System.Drawing.Point(20, 53);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(175, 151);
            this.panel5.TabIndex = 37;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(72, 14);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(27, 15);
            this.label14.TabIndex = 34;
            this.label14.Text = "Lux";
            // 
            // SD_light
            // 
            this.SD_light.Location = new System.Drawing.Point(17, 13);
            this.SD_light.Name = "SD_light";
            this.SD_light.Size = new System.Drawing.Size(144, 111);
            this.SD_light.TabIndex = 33;
            this.SD_light.Text = "temperature";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(67, 127);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(40, 16);
            this.label9.TabIndex = 25;
            this.label9.Text = "Light";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(40, 27);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(88, 20);
            this.label12.TabIndex = 38;
            this.label12.Text = "Light state:";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.DarkGray;
            this.panel7.Controls.Add(this.label15);
            this.panel7.Controls.Add(this.SD_temperature);
            this.panel7.Controls.Add(this.label10);
            this.panel7.Location = new System.Drawing.Point(207, 52);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(175, 151);
            this.panel7.TabIndex = 38;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(76, 14);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(20, 15);
            this.label15.TabIndex = 35;
            this.label15.Text = "°C";
            // 
            // SD_temperature
            // 
            this.SD_temperature.Location = new System.Drawing.Point(18, 13);
            this.SD_temperature.Name = "SD_temperature";
            this.SD_temperature.Size = new System.Drawing.Size(144, 111);
            this.SD_temperature.TabIndex = 31;
            this.SD_temperature.Text = "temperature";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(41, 128);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(96, 16);
            this.label10.TabIndex = 36;
            this.label10.Text = "Temperature";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.DarkGray;
            this.panel8.Controls.Add(this.label16);
            this.panel8.Controls.Add(this.SD_humidity);
            this.panel8.Controls.Add(this.label11);
            this.panel8.Location = new System.Drawing.Point(395, 52);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(175, 151);
            this.panel8.TabIndex = 38;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(80, 14);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(18, 15);
            this.label16.TabIndex = 37;
            this.label16.Text = "%";
            // 
            // SD_humidity
            // 
            this.SD_humidity.Location = new System.Drawing.Point(16, 13);
            this.SD_humidity.Name = "SD_humidity";
            this.SD_humidity.Size = new System.Drawing.Size(144, 111);
            this.SD_humidity.TabIndex = 32;
            this.SD_humidity.Text = "SD_temperature";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(55, 128);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(67, 16);
            this.label11.TabIndex = 37;
            this.label11.Text = "Humidity";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(212, 27);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(53, 20);
            this.label17.TabIndex = 40;
            this.label17.Text = "Temp:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(406, 28);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(59, 20);
            this.label18.TabIndex = 41;
            this.label18.Text = "Humid:";
            // 
            // TXB_temperature
            // 
            this.TXB_temperature.Location = new System.Drawing.Point(270, 28);
            this.TXB_temperature.Name = "TXB_temperature";
            this.TXB_temperature.Size = new System.Drawing.Size(67, 20);
            this.TXB_temperature.TabIndex = 42;
            this.TXB_temperature.TextChanged += new System.EventHandler(this.TXB_temperature_TextChanged);
            // 
            // TXB_humidity
            // 
            this.TXB_humidity.Location = new System.Drawing.Point(470, 28);
            this.TXB_humidity.Name = "TXB_humidity";
            this.TXB_humidity.Size = new System.Drawing.Size(62, 20);
            this.TXB_humidity.TabIndex = 43;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Silver;
            this.panel6.Controls.Add(this.BL_rain);
            this.panel6.Controls.Add(this.BL_humidity);
            this.panel6.Controls.Add(this.BL_temperature);
            this.panel6.Controls.Add(this.TXB_rain);
            this.panel6.Controls.Add(this.label20);
            this.panel6.Controls.Add(this.panel12);
            this.panel6.Controls.Add(this.TXB_humidity);
            this.panel6.Controls.Add(this.TXB_temperature);
            this.panel6.Controls.Add(this.label18);
            this.panel6.Controls.Add(this.label17);
            this.panel6.Controls.Add(this.panel8);
            this.panel6.Controls.Add(this.LB_light);
            this.panel6.Controls.Add(this.panel7);
            this.panel6.Controls.Add(this.label12);
            this.panel6.Controls.Add(this.panel5);
            this.panel6.Location = new System.Drawing.Point(581, 47);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(777, 217);
            this.panel6.TabIndex = 35;
            this.panel6.Paint += new System.Windows.Forms.PaintEventHandler(this.panel6_Paint);
            // 
            // BL_rain
            // 
            this.BL_rain.Color = System.Drawing.Color.Red;
            this.BL_rain.Location = new System.Drawing.Point(720, 27);
            this.BL_rain.Name = "BL_rain";
            this.BL_rain.On = true;
            this.BL_rain.Size = new System.Drawing.Size(25, 23);
            this.BL_rain.TabIndex = 49;
            this.BL_rain.Text = "ledBulb3";
            // 
            // BL_humidity
            // 
            this.BL_humidity.Color = System.Drawing.Color.Red;
            this.BL_humidity.Location = new System.Drawing.Point(538, 27);
            this.BL_humidity.Name = "BL_humidity";
            this.BL_humidity.On = true;
            this.BL_humidity.Size = new System.Drawing.Size(25, 23);
            this.BL_humidity.TabIndex = 48;
            this.BL_humidity.Text = "ledBulb2";
            // 
            // BL_temperature
            // 
            this.BL_temperature.Color = System.Drawing.Color.Red;
            this.BL_temperature.Location = new System.Drawing.Point(353, 27);
            this.BL_temperature.Name = "BL_temperature";
            this.BL_temperature.On = true;
            this.BL_temperature.Size = new System.Drawing.Size(25, 23);
            this.BL_temperature.TabIndex = 47;
            this.BL_temperature.Text = "ledBulb1";
            // 
            // TXB_rain
            // 
            this.TXB_rain.Location = new System.Drawing.Point(648, 28);
            this.TXB_rain.Name = "TXB_rain";
            this.TXB_rain.Size = new System.Drawing.Size(62, 20);
            this.TXB_rain.TabIndex = 46;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(597, 28);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(46, 20);
            this.label20.TabIndex = 45;
            this.label20.Text = "Rain:";
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.DarkGray;
            this.panel12.Controls.Add(this.label21);
            this.panel12.Controls.Add(this.SD_rain);
            this.panel12.Controls.Add(this.label22);
            this.panel12.Location = new System.Drawing.Point(585, 52);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(175, 151);
            this.panel12.TabIndex = 44;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(80, 14);
            this.label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(18, 15);
            this.label21.TabIndex = 37;
            this.label21.Text = "%";
            // 
            // SD_rain
            // 
            this.SD_rain.Location = new System.Drawing.Point(16, 13);
            this.SD_rain.Name = "SD_rain";
            this.SD_rain.Size = new System.Drawing.Size(144, 111);
            this.SD_rain.TabIndex = 32;
            this.SD_rain.Text = "SD_temperature";
            this.SD_rain.ChildChanged += new System.EventHandler<System.Windows.Forms.Integration.ChildChangedEventArgs>(this.solidGauge1_ChildChanged);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(68, 127);
            this.label22.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(39, 16);
            this.label22.TabIndex = 37;
            this.label22.Text = "Rain";
            // 
            // LB_light
            // 
            this.LB_light.Location = new System.Drawing.Point(133, 25);
            this.LB_light.Name = "LB_light";
            this.LB_light.On = true;
            this.LB_light.Size = new System.Drawing.Size(25, 23);
            this.LB_light.TabIndex = 39;
            this.LB_light.Text = "LB_light";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(577, 20);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(160, 24);
            this.label13.TabIndex = 36;
            this.label13.Text = "Processed data:";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.Gray;
            this.panel9.Location = new System.Drawing.Point(12, 290);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(1383, 10);
            this.panel9.TabIndex = 37;
            this.panel9.Paint += new System.Windows.Forms.PaintEventHandler(this.panel9_Paint);
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.Gray;
            this.panel10.Location = new System.Drawing.Point(550, 15);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(10, 284);
            this.panel10.TabIndex = 38;
            this.panel10.Paint += new System.Windows.Forms.PaintEventHandler(this.panel10_Paint);
            // 
            // bt_setting
            // 
            this.bt_setting.BackColor = System.Drawing.Color.DarkGray;
            this.bt_setting.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_setting.Location = new System.Drawing.Point(12, 12);
            this.bt_setting.Name = "bt_setting";
            this.bt_setting.Size = new System.Drawing.Size(98, 32);
            this.bt_setting.TabIndex = 41;
            this.bt_setting.Text = "Settings";
            this.bt_setting.UseVisualStyleBackColor = false;
            this.bt_setting.Click += new System.EventHandler(this.bt_setting_Click);
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.Silver;
            this.panel11.Controls.Add(this.LVCHART_Rain);
            this.panel11.Controls.Add(this.label19);
            this.panel11.Location = new System.Drawing.Point(1026, 344);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(333, 348);
            this.panel11.TabIndex = 29;
            this.panel11.Paint += new System.Windows.Forms.PaintEventHandler(this.panel11_Paint);
            // 
            // LVCHART_Rain
            // 
            this.LVCHART_Rain.BackColor = System.Drawing.Color.White;
            this.LVCHART_Rain.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.LVCHART_Rain.Location = new System.Drawing.Point(10, 44);
            this.LVCHART_Rain.Name = "LVCHART_Rain";
            this.LVCHART_Rain.Size = new System.Drawing.Size(309, 290);
            this.LVCHART_Rain.TabIndex = 23;
            this.LVCHART_Rain.Text = "cartesianChart3";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(141, 14);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(42, 18);
            this.label19.TabIndex = 24;
            this.label19.Text = "Rain";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Silver;
            this.panel1.Controls.Add(this.panel14);
            this.panel1.Controls.Add(this.panel13);
            this.panel1.Location = new System.Drawing.Point(12, 88);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(514, 176);
            this.panel1.TabIndex = 42;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.DarkGray;
            this.panel14.Controls.Add(this.panel15);
            this.panel14.Controls.Add(this.BT_M_Servo_SX_OFF);
            this.panel14.Controls.Add(this.label8);
            this.panel14.Controls.Add(this.BT_M_Servo_SX_ON);
            this.panel14.Controls.Add(this.BT_M_Servo_DX_OFF);
            this.panel14.Controls.Add(this.label4);
            this.panel14.Controls.Add(this.BT_M_Servo_DX_ON);
            this.panel14.Location = new System.Drawing.Point(189, 34);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(314, 128);
            this.panel14.TabIndex = 44;
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.Gray;
            this.panel15.Location = new System.Drawing.Point(154, 9);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(10, 111);
            this.panel15.TabIndex = 39;
            // 
            // BT_M_Servo_SX_OFF
            // 
            this.BT_M_Servo_SX_OFF.BackColor = System.Drawing.Color.DarkGray;
            this.BT_M_Servo_SX_OFF.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BT_M_Servo_SX_OFF.Location = new System.Drawing.Point(193, 88);
            this.BT_M_Servo_SX_OFF.Name = "BT_M_Servo_SX_OFF";
            this.BT_M_Servo_SX_OFF.Size = new System.Drawing.Size(98, 32);
            this.BT_M_Servo_SX_OFF.TabIndex = 50;
            this.BT_M_Servo_SX_OFF.Text = "OFF";
            this.BT_M_Servo_SX_OFF.UseVisualStyleBackColor = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(196, 10);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(100, 25);
            this.label8.TabIndex = 48;
            this.label8.Text = "Servo Dx";
            // 
            // BT_M_Servo_SX_ON
            // 
            this.BT_M_Servo_SX_ON.BackColor = System.Drawing.Color.DarkGray;
            this.BT_M_Servo_SX_ON.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BT_M_Servo_SX_ON.Location = new System.Drawing.Point(193, 50);
            this.BT_M_Servo_SX_ON.Name = "BT_M_Servo_SX_ON";
            this.BT_M_Servo_SX_ON.Size = new System.Drawing.Size(98, 32);
            this.BT_M_Servo_SX_ON.TabIndex = 49;
            this.BT_M_Servo_SX_ON.Text = "ON";
            this.BT_M_Servo_SX_ON.UseVisualStyleBackColor = false;
            // 
            // BT_M_Servo_DX_OFF
            // 
            this.BT_M_Servo_DX_OFF.BackColor = System.Drawing.Color.DarkGray;
            this.BT_M_Servo_DX_OFF.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BT_M_Servo_DX_OFF.Location = new System.Drawing.Point(24, 88);
            this.BT_M_Servo_DX_OFF.Name = "BT_M_Servo_DX_OFF";
            this.BT_M_Servo_DX_OFF.Size = new System.Drawing.Size(98, 32);
            this.BT_M_Servo_DX_OFF.TabIndex = 47;
            this.BT_M_Servo_DX_OFF.Text = "OFF";
            this.BT_M_Servo_DX_OFF.UseVisualStyleBackColor = false;
            this.BT_M_Servo_DX_OFF.Click += new System.EventHandler(this.BT_M_Servo_DX_OFF_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(28, 10);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 25);
            this.label4.TabIndex = 46;
            this.label4.Text = "Servo Sx";
            // 
            // BT_M_Servo_DX_ON
            // 
            this.BT_M_Servo_DX_ON.BackColor = System.Drawing.Color.DarkGray;
            this.BT_M_Servo_DX_ON.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BT_M_Servo_DX_ON.Location = new System.Drawing.Point(24, 50);
            this.BT_M_Servo_DX_ON.Name = "BT_M_Servo_DX_ON";
            this.BT_M_Servo_DX_ON.Size = new System.Drawing.Size(98, 32);
            this.BT_M_Servo_DX_ON.TabIndex = 46;
            this.BT_M_Servo_DX_ON.Text = "ON";
            this.BT_M_Servo_DX_ON.UseVisualStyleBackColor = false;
            this.BT_M_Servo_DX_ON.Click += new System.EventHandler(this.BT_M_Servo_DX_ON_Click);
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.DarkGray;
            this.panel13.Controls.Add(this.label3);
            this.panel13.Controls.Add(this.BT_M_light_OFF);
            this.panel13.Controls.Add(this.BT_M_light_ON);
            this.panel13.Location = new System.Drawing.Point(8, 34);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(175, 128);
            this.panel13.TabIndex = 43;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(56, 10);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 25);
            this.label3.TabIndex = 44;
            this.label3.Text = "Light";
            // 
            // BT_M_light_OFF
            // 
            this.BT_M_light_OFF.BackColor = System.Drawing.Color.DarkGray;
            this.BT_M_light_OFF.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BT_M_light_OFF.Location = new System.Drawing.Point(39, 88);
            this.BT_M_light_OFF.Name = "BT_M_light_OFF";
            this.BT_M_light_OFF.Size = new System.Drawing.Size(98, 32);
            this.BT_M_light_OFF.TabIndex = 45;
            this.BT_M_light_OFF.Text = "OFF";
            this.BT_M_light_OFF.UseVisualStyleBackColor = false;
            this.BT_M_light_OFF.Click += new System.EventHandler(this.BT_M_light_OFF_Click);
            // 
            // BT_M_light_ON
            // 
            this.BT_M_light_ON.BackColor = System.Drawing.Color.DarkGray;
            this.BT_M_light_ON.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BT_M_light_ON.Location = new System.Drawing.Point(39, 50);
            this.BT_M_light_ON.Name = "BT_M_light_ON";
            this.BT_M_light_ON.Size = new System.Drawing.Size(98, 32);
            this.BT_M_light_ON.TabIndex = 44;
            this.BT_M_light_ON.Text = "ON";
            this.BT_M_light_ON.UseVisualStyleBackColor = false;
            this.BT_M_light_ON.Click += new System.EventHandler(this.BT_M_light_ON_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(8, 61);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(136, 24);
            this.label1.TabIndex = 43;
            this.label1.Text = "Manual input:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Main_Window
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(1370, 712);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.bt_setting);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Main_Window";
            this.Text = "GardenLight";
            this.Load += new System.EventHandler(this.Main_Window_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label5;
        private LiveCharts.WinForms.CartesianChart cartesianChart1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label6;
        private LiveCharts.WinForms.CartesianChart LVCHART_temperature;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label LVCHART_humidity;
        private LiveCharts.WinForms.CartesianChart LVCHART_Humid;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label14;
        private LiveCharts.WinForms.SolidGauge SD_light;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label15;
        private LiveCharts.WinForms.SolidGauge SD_temperature;
        private System.Windows.Forms.Label label10;
        private Bulb.LedBulb LB_light;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label16;
        private LiveCharts.WinForms.SolidGauge SD_humidity;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox TXB_temperature;
        private System.Windows.Forms.TextBox TXB_humidity;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Button bt_setting;
        private System.Windows.Forms.Panel panel11;
        private LiveCharts.WinForms.CartesianChart LVCHART_Rain;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox TXB_rain;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label21;
        private LiveCharts.WinForms.SolidGauge SD_rain;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Button BT_M_Servo_SX_OFF;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button BT_M_Servo_SX_ON;
        private System.Windows.Forms.Button BT_M_Servo_DX_OFF;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button BT_M_Servo_DX_ON;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button BT_M_light_OFF;
        private System.Windows.Forms.Button BT_M_light_ON;
        private System.Windows.Forms.Panel panel15;
        private Bulb.LedBulb BL_rain;
        private Bulb.LedBulb BL_humidity;
        private Bulb.LedBulb BL_temperature;
    }
}

