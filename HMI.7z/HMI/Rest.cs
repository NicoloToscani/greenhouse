﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace Progetto_Supervisione_ITIS
{
    class Rest
    {


        const string READKEY = "MSO3J9WPKF6XRPRO";
        string strUpdateBase = "http://api.thingspeak.com/channels/1663304/fields/1.json?api_key=MSO3J9WPKF6XRPRO&results=2";

        public List<float> values;

        // Timer
        System.Timers.Timer _chartTimer = new System.Timers.Timer();


        public List<float> getValues()
        {
            return this.values;
        }


        public Rest()
        {

            _chartTimer = new System.Timers.Timer();
            _chartTimer.Interval = 20000;
            _chartTimer.Elapsed += OnTimerElapsedChart;
            _chartTimer.Start();

            // // Console remain open
            // while (Console.Read() != 'q') ;

            this.values = new List<float>();
        }

        private void OnTimerElapsedChart(object sender, ElapsedEventArgs e)
        {
            WebRequest ThingsSpeakReq;
            HttpWebResponse ThingsSpeakResp;

            ThingsSpeakReq = WebRequest.Create(strUpdateBase);
            ThingsSpeakResp = (HttpWebResponse)ThingsSpeakReq.GetResponse();

            Stream stream = ThingsSpeakResp.GetResponseStream();
            StreamReader Reader = new StreamReader(stream);
            String value = Reader.ReadToEnd();

            int start = value.LastIndexOf("field1");
            int start2 = value.LastIndexOf("created_at");
            int start3 = value.LastIndexOf("created_at");
            string segments = value.Substring(start + 9, 4);
            string time = value.Substring(start2 + 15, 8);
            string ora = value.Substring(start3 + 24, 8);
            Console.WriteLine("VALORE: " + segments + "\nDATA: " + time + "\nORA: " + ora + "\n\n");
            Console.ReadLine();
            values.Add(float.Parse(segments) / 100);
        }

        
    }
}
